# Accent Bias at Scale: Whisper WER on Indian vs. American English

LaTeX source for the research paper. Built for Overleaf.

## Importing into Overleaf

1. Overleaf > New Project > Upload Project > choose this zip.
2. Menu > Compiler: **pdfLaTeX**. Main document: `main.tex`.
3. Recompile. Overleaf runs Biber automatically for the bibliography.

Compiles cleanly with TeX Live 2023 or later. Locally: `latexmk -pdf main.tex`.

## Layout

```
main.tex                    preamble, title block, section order
sections/abstract.tex       (unnumbered, sits inside the abstract environment)
sections/00-Introduction.tex
sections/01-Related-Works.tex
sections/02-Methodology.tex
sections/03-Experimental-Setup.tex
sections/04-Results.tex
sections/05-Discussion.tex
sections/06-Conclusion.tex
sections/07-Appendix.tex     (after the references; GitHub and website links)
references.bib              Chicago author-date entries (biblatex-chicago)
figures/fig1_wer_by_model.pdf
figures/fig2_disparity_ratio.pdf
figures/fig3_wer_distribution.pdf
figures/fig4_cross_architecture.pdf
```

Section order follows the agreed outline (Abstract, Introduction, Related
Works, Methodology, Experimental Set Up, Results, Discussion, Conclusion).
To change it, reorder the `\input` lines in `main.tex`.

## Placeholders

None remain. The `\placeholder{...}` macro is still defined in `main.tex`
(it prints a yellow box) in case you need to mark text for later.

## Citations

In-text citations use `\parencite{key}` for parenthetical and
`\textcite{key}` for narrative form, with page numbers as
`\parencite[7684]{koenecke2020}`. Keys are in `references.bib`.

## Compiled PDF

`ASR Final.pdf` is the compiled output of this project, for reference.
Overleaf ignores it when building.

## Figures

Figures are the vector PDFs produced by `make_figures.py` in the code
repository. Regenerate them there and drop the new PDFs into `figures/`
if the data changes.
